
from datetime import timedelta
from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parent.parent

try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass


def env_bool(name, default=None):
    """
    Strictly parse an environment variable as a boolean.

    Accepts only the intended true/false representations below. Returns
    `default` when the variable is unset. Raises ValueError for any other
    value so callers can fail fast instead of silently misinterpreting input.
    """
    val = os.environ.get(name)
    if val is None:
        return default
    normalized = val.strip().lower()
    if normalized in ("1", "true", "yes", "on"):
        return True
    if normalized in ("0", "false", "no", "off"):
        return False
    raise ValueError(
        f"Environment variable {name!r} must be one of "
        "1/true/yes/on or 0/false/no/off."
    )


def env_list(name, default=""):
    val = os.environ.get(name, default)
    return [item.strip() for item in val.split(",") if item.strip()]


from django.core.exceptions import ImproperlyConfigured 

DJANGO_ENV = os.environ.get("DJANGO_ENV", "development").strip().lower()
IS_DEVELOPMENT = DJANGO_ENV == "development"


if IS_DEVELOPMENT:
    SECRET_KEY = os.environ.get(
        "DJANGO_SECRET_KEY",
        "django-insecure-dev-only-do-not-use-in-production",
    )
else:
    SECRET_KEY = os.environ.get("DJANGO_SECRET_KEY")
    if not SECRET_KEY:
        raise ImproperlyConfigured(
            "DJANGO_SECRET_KEY is required in a non-development environment."
        )


if IS_DEVELOPMENT:
    DEBUG = env_bool("DJANGO_DEBUG", default=True)
else:
    raw_debug = os.environ.get("DJANGO_DEBUG")
    if raw_debug is None or raw_debug.strip() == "":
        raise ImproperlyConfigured(
            "DJANGO_DEBUG is required in a non-development environment."
        )
    try:
        DEBUG = env_bool("DJANGO_DEBUG")
    except ValueError as exc:
        raise ImproperlyConfigured(str(exc)) from exc

ALLOWED_HOSTS = env_list("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1")
# HTTPS / production security
SECURE_SSL_REDIRECT = env_bool(
    "SECURE_SSL_REDIRECT",
    default=not IS_DEVELOPMENT,
)

SESSION_COOKIE_SECURE = env_bool(
    "SESSION_COOKIE_SECURE",
    default=not IS_DEVELOPMENT,
)

CSRF_COOKIE_SECURE = env_bool(
    "CSRF_COOKIE_SECURE",
    default=not IS_DEVELOPMENT,
)

SECURE_HSTS_SECONDS = int(
    os.environ.get(
        "SECURE_HSTS_SECONDS",
        "0" if IS_DEVELOPMENT else "31536000",
    )
)

# APPLICATIONS
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # Third party
    "rest_framework",
    "rest_framework_simplejwt",
    "rest_framework_simplejwt.token_blacklist",

    "corsheaders",
    "django_filters",
    # Local
    "store",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "nyra.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "nyra.wsgi.application"
ASGI_APPLICATION = "nyra.asgi.application"


if os.environ.get("DB_ENGINE", "postgres") == "sqlite":
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": os.environ.get("DB_NAME"),
            "USER": os.environ.get("DB_USER"),
            "PASSWORD": os.environ.get("DB_PASSWORD"),
            "HOST": os.environ.get("DB_HOST", "localhost"),
            "PORT": os.environ.get("DB_PORT", "5432"),
        }
    }

# PASSWORD VALIDATION
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# INTERNATIONALIZATION
LANGUAGE_CODE = "en-us"
TIME_ZONE = os.environ.get("TIME_ZONE", "Africa/Algiers")
USE_I18N = True
USE_TZ = True

# STATIC & MEDIA FILES
STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

MEDIA_URL = "media/"
MEDIA_ROOT = BASE_DIR / "media"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# DJANGO REST FRAMEWORK
REST_FRAMEWORK = {
    "DEFAULT_AUTHENTICATION_CLASSES": (
        "store.authentication.CookieJWTAuthentication",
    ),
    "DEFAULT_PERMISSION_CLASSES": (
        "rest_framework.permissions.AllowAny",
    ),
    "DEFAULT_FILTER_BACKENDS": (
        "django_filters.rest_framework.DjangoFilterBackend",
        "rest_framework.filters.SearchFilter",
        "rest_framework.filters.OrderingFilter",
    ),
    "DEFAULT_PAGINATION_CLASS": "rest_framework.pagination.PageNumberPagination",
    "PAGE_SIZE": int(os.environ.get("PAGE_SIZE", 12)),
    "DEFAULT_PARSER_CLASSES": (
        "rest_framework.parsers.JSONParser",
        "rest_framework.parsers.MultiPartParser",
        "rest_framework.parsers.FormParser",
    ),
   
    "DEFAULT_THROTTLE_CLASSES": (
        "rest_framework.throttling.ScopedRateThrottle",
    ),
    "DEFAULT_THROTTLE_RATES": {
        "staff_login": "5/min",
        "order_create": "10/min",
        "contact_create": "10/min",
    },
    "EXCEPTION_HANDLER": "store.exceptions.custom_exception_handler",
}

# SIMPLE JWT
SIMPLE_JWT = {
    "ACCESS_TOKEN_LIFETIME": timedelta(minutes=int(os.environ.get("JWT_ACCESS_MINUTES", 60))),
    "REFRESH_TOKEN_LIFETIME": timedelta(days=int(os.environ.get("JWT_REFRESH_DAYS", 7))),
    "ROTATE_REFRESH_TOKENS": True,
    "BLACKLIST_AFTER_ROTATION": True,
    "AUTH_HEADER_TYPES": ("Bearer",),
}

# CORS
CORS_ALLOWED_ORIGINS = env_list(
    "CORS_ALLOWED_ORIGINS",
    "http://localhost:3000,http://127.0.0.1:3000",
)
CORS_ALLOW_CREDENTIALS = True


from corsheaders.defaults import default_headers as _cors_default_headers  # noqa: E402

CORS_ALLOW_HEADERS = list(_cors_default_headers) + ["x-csrftoken"]

# ---------------------------------------------------------------------------
# Cookie-based admin JWT authentication
# ---------------------------------------------------------------------------
# The admin access/refresh tokens are issued as HttpOnly cookies (see
# store/jwt_cookies.py and store/authentication.py) instead of being stored
# in localStorage, so they can't be read or exfiltrated by JavaScript/XSS.
JWT_AUTH_COOKIE = os.environ.get("JWT_AUTH_COOKIE", "nyra_access_token")
JWT_REFRESH_COOKIE = os.environ.get("JWT_REFRESH_COOKIE", "nyra_refresh_token")

# Secure defaults to "not development" like the other cookie flags above —
# i.e. plain HTTP localhost works out of the box, but any non-development
# deployment requires HTTPS-only cookies unless explicitly overridden.
JWT_COOKIE_SECURE = env_bool("JWT_COOKIE_SECURE", default=not IS_DEVELOPMENT)

# "Lax" is correct for this project's actual architecture: frontend
# (localhost:3000) and backend (localhost:8000) are same-site (same
# registrable domain, different port), and SameSite is defined per-site,
# not per-port, so Lax cookies ARE sent on the frontend's same-site fetch
# calls. If frontend and backend ever move to genuinely different
# registrable domains in production (e.g. app.example.com calling
# api.other-domain.com), this must be set to "None" (which also forces
# Secure=True) via the JWT_COOKIE_SAMESITE env var.
JWT_COOKIE_SAMESITE = os.environ.get("JWT_COOKIE_SAMESITE", "Lax")

# Unset by default (host-only cookie). Set e.g. ".nyra-jewellery.com" in
# production only if the API and frontend share a parent domain.
JWT_COOKIE_DOMAIN = os.environ.get("JWT_COOKIE_DOMAIN") or None

# Browsers reject SameSite=None cookies that aren't also Secure — enforce
# that regardless of JWT_COOKIE_SECURE/IS_DEVELOPMENT so a misconfigured
# cross-domain deployment fails loudly instead of silently dropping cookies.
if JWT_COOKIE_SAMESITE.lower() == "none":
    JWT_COOKIE_SECURE = True

# CSRF: cookie-based JWT auth means the browser now attaches the admin's
# credential automatically on cross-site requests, so CSRF protection is
# required for unsafe methods (see store/authentication.py::enforce_csrf).
# Django 4+ also requires the Origin header's scheme+host+port to match one
# of CSRF_TRUSTED_ORIGINS for any cross-origin unsafe request — the
# frontend origin(s) must be listed here (reusing CORS_ALLOWED_ORIGINS
# keeps the two lists from drifting apart).
CSRF_TRUSTED_ORIGINS = env_list("CSRF_TRUSTED_ORIGINS", ",".join(CORS_ALLOWED_ORIGINS))
CSRF_COOKIE_SAMESITE = JWT_COOKIE_SAMESITE
CSRF_COOKIE_HTTPONLY = False  # must stay JS-readable so the frontend can echo it back
CSRF_HEADER_NAME = "HTTP_X_CSRFTOKEN"

DATA_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024
FILE_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024
