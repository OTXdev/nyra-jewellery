import Image from 'next/image'
import Link from 'next/link'

const CATEGORIES = [
  { label: 'Rings', href: '/shop?category=rings', image: '/images/ring-emerald.png' },
  {
    label: 'Necklaces',
    href: '/shop?category=necklaces',
    image: '/images/necklace-pendant.png',
  },
  {
    label: 'Bracelets',
    href: '/shop?category=bracelets',
    image: '/images/bracelet-tennis.png',
  },
  { label: 'Jewelry Sets', href: '/shop?category=sets', image: '/images/set-bridal.png' },
]

export function Categories() {
  return (
    <div className="grid grid-cols-2 gap-4 sm:gap-6 lg:grid-cols-4">
      {CATEGORIES.map((c) => (
        <Link
          key={c.label}
          href={c.href}
          className="group relative aspect-[3/4] overflow-hidden rounded-3xl border border-border shadow-sm"
        >
          <Image
            src={c.image || '/placeholder.svg'}
            alt={c.label}
            fill
            sizes="(max-width: 1024px) 50vw, 25vw"
            className="object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-primary/70 via-primary/10 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-5">
            <p className="font-serif text-xl font-medium text-primary-foreground">
              {c.label}
            </p>
            <p className="mt-0.5 text-sm text-primary-foreground/80 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
              Shop now →
            </p>
          </div>
        </Link>
      ))}
    </div>
  )
}
