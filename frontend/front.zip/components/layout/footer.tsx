'use client'

import Link from 'next/link'
import { Mail, MapPin, Phone } from 'lucide-react'
import { useState } from 'react'
import { BRAND } from '@/lib/data'
import { Facebook, Instagram } from '@/components/icons/brand-icons'

export function Footer() {
  const [email, setEmail] = useState('')
  const [subscribed, setSubscribed] = useState(false)

  return (
    <footer className="mt-24 border-t border-border bg-primary text-primary-foreground">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <span className="font-serif text-3xl font-semibold tracking-wide">
              Nyra
            </span>
            <span className="mt-1 block text-[0.6rem] uppercase tracking-[0.35em] text-primary-foreground/70">
              Jewellery
            </span>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-primary-foreground/80">
              Handcrafted luxury jewelry for the moments that matter. Browse,
              request, and let us take care of the rest.
            </p>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold uppercase tracking-widest text-accent">
              Explore
            </h4>
            <ul className="space-y-2.5 text-sm text-primary-foreground/80">
              {[
                { href: '/shop', label: 'Shop All' },
                { href: '/collections', label: 'Collections' },
                { href: '/promotions', label: 'Promotions' },
                { href: '/about', label: 'About Us' },
                { href: '/contact', label: 'Contact' },
              ].map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="transition-colors hover:text-accent"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold uppercase tracking-widest text-accent">
              Get in touch
            </h4>
            <ul className="space-y-3 text-sm text-primary-foreground/80">
              <li className="flex items-center gap-2.5">
                <Phone className="size-4 text-accent" />
                <a href={`tel:+${BRAND.whatsapp}`}>{BRAND.whatsappDisplay}</a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="size-4 text-accent" />
                <a href={`mailto:${BRAND.email}`}>{BRAND.email}</a>
              </li>
              <li className="flex items-center gap-2.5">
                <MapPin className="size-4 text-accent" />
                <span>Alger, Algeria</span>
              </li>
            </ul>
            <div className="mt-5 flex gap-3">
              <a
                href={BRAND.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="rounded-full border border-primary-foreground/20 p-2 transition-colors hover:border-accent hover:text-accent"
              >
                <Instagram className="size-4" />
              </a>
              <a
                href={BRAND.facebook}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="rounded-full border border-primary-foreground/20 p-2 transition-colors hover:border-accent hover:text-accent"
              >
                <Facebook className="size-4" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold uppercase tracking-widest text-accent">
              Newsletter
            </h4>
            <p className="mb-4 text-sm text-primary-foreground/80">
              Be the first to discover new arrivals and private promotions.
            </p>
            {subscribed ? (
              <p className="rounded-xl bg-primary-foreground/10 px-4 py-3 text-sm text-accent">
                Thank you for subscribing.
              </p>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  if (email.trim()) setSubscribed(true)
                }}
                className="flex flex-col gap-2 sm:flex-row"
              >
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email"
                  className="w-full rounded-full border border-primary-foreground/20 bg-primary-foreground/5 px-4 py-2.5 text-sm text-primary-foreground outline-none placeholder:text-primary-foreground/50 focus:border-accent"
                />
                <button
                  type="submit"
                  className="rounded-full bg-accent px-5 py-2.5 text-sm font-medium text-accent-foreground transition-opacity hover:opacity-90"
                >
                  Join
                </button>
              </form>
            )}
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-primary-foreground/15 pt-8 text-xs text-primary-foreground/60 sm:flex-row">
          <p>
            © {new Date().getFullYear()} Nyra Jewellery. All rights reserved.
          </p>
          <Link href="/admin" className="transition-colors hover:text-accent">
            Admin
          </Link>
        </div>
      </div>
    </footer>
  )
}
