"use client"

import { useEffect, useMemo, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { LayoutDashboard, Package, Pencil, Plus, ShoppingCart, Trash2 } from "lucide-react"
import { useStore } from "@/components/store/store-provider"
import { useAdminAuth } from "@/lib/admin-auth"
import {
  ApiError,
  fetchAdminOrders,
  fetchAdminStats,
  fetchCategories,
  updateOrderStatus as apiUpdateOrderStatus,
  type AdminStats,
  type ProductWritePayload,
} from "@/lib/api"
import { CATEGORY_LABELS } from "@/lib/data"
import { formatDZD } from "@/lib/format"
import type { Category, Order, OrderStatus, Product } from "@/lib/types"
import { cn } from "@/lib/utils"

type Tab = "overview" | "orders" | "products"

const STATUS_STYLES: Record<OrderStatus, string> = {
  new: "bg-accent/30 text-accent-foreground",
  confirmed: "bg-primary/15 text-primary",
  shipped: "bg-primary/15 text-primary",
  delivered: "bg-primary text-primary-foreground",
  cancelled: "bg-destructive/15 text-destructive",
}

export function AdminDashboard() {
  const { token, authed, checking, login, logout } = useAdminAuth()
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [err, setErr] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  if (checking) {
    return <div className="py-24 text-center text-muted-foreground">Loading…</div>
  }

  if (!authed || !token) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-sm flex-col justify-center px-4">
        <div className="rounded-3xl border border-border bg-card p-8 shadow-sm">
          <div className="mx-auto mb-4 flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
            <LayoutDashboard className="size-6" />
          </div>
          <h1 className="text-center font-serif text-2xl">Admin Access</h1>
          <p className="mt-1 text-center text-sm text-muted-foreground">Log in to manage the store.</p>
          <form
            onSubmit={async (e) => {
              e.preventDefault()
              setErr(null)
              setSubmitting(true)
              try {
                await login(username, password)
              } catch (error) {
                setErr(error instanceof ApiError ? error.message : "Login failed. Please try again.")
              } finally {
                setSubmitting(false)
              }
            }}
            className="mt-6 space-y-3"
          >
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              className="input text-center"
              autoComplete="username"
            />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className="input text-center"
              autoComplete="current-password"
            />
            {err && <p className="text-center text-xs text-destructive">{err}</p>}
            <button
              type="submit"
              disabled={submitting}
              className="w-full rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground disabled:opacity-60"
            >
              {submitting ? "Signing in…" : "Enter dashboard"}
            </button>
          </form>
          <Link href="/" className="mt-4 block text-center text-xs text-muted-foreground hover:text-foreground">
            Back to store
          </Link>
        </div>
      </div>
    )
  }

  return <Dashboard token={token} onLogout={logout} />
}

function Dashboard({ token, onLogout }: { token: string; onLogout: () => void }) {
  const { products, deleteProduct, productsLoading } = useStore()
  const [tab, setTab] = useState<Tab>("overview")
  const [editing, setEditing] = useState<Product | "new" | null>(null)
  const [orders, setOrders] = useState<Order[]>([])
  const [ordersLoading, setOrdersLoading] = useState(true)
  const [stats, setStats] = useState<AdminStats | null>(null)

  useEffect(() => {
    fetchAdminOrders(token)
      .then(setOrders)
      .catch(() => setOrders([]))
      .finally(() => setOrdersLoading(false))
    fetchAdminStats(token)
      .then(setStats)
      .catch(() => setStats(null))
  }, [token])

  async function handleStatusChange(id: number, status: OrderStatus) {
    const updated = await apiUpdateOrderStatus(token, id, status)
    setOrders((prev) => prev.map((o) => (o.id === id ? updated : o)))
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-serif text-3xl">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Manage products and orders</p>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/" className="rounded-full border border-border px-4 py-2 text-sm hover:bg-secondary">
            View store
          </Link>
          <button onClick={onLogout} className="rounded-full border border-border px-4 py-2 text-sm hover:bg-secondary">
            Log out
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <Stat label="Total revenue" value={stats ? formatDZD(stats.totalRevenue) : "…"} icon={ShoppingCart} />
        <Stat
          label="Orders"
          value={stats ? `${stats.totalOrders}` : "…"}
          sub={stats ? `${stats.ordersByStatus.new ?? 0} new` : undefined}
          icon={Package}
        />
        <Stat label="Products" value={stats ? `${stats.totalProducts}` : `${products.length}`} icon={LayoutDashboard} />
      </div>

      {/* Tabs */}
      <div className="mt-8 flex gap-2 border-b border-border">
        {(["overview", "orders", "products"] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "-mb-px border-b-2 px-4 py-2.5 text-sm font-medium capitalize transition-colors",
              tab === t ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {tab === "overview" && <Overview orders={orders} loading={ordersLoading} />}
        {tab === "orders" && (
          <OrdersTable orders={orders} loading={ordersLoading} onStatus={handleStatusChange} />
        )}
        {tab === "products" && (
          <ProductsTable
            products={products}
            loading={productsLoading}
            onEdit={setEditing}
            onNew={() => setEditing("new")}
            onDelete={(slug) => deleteProduct(slug)}
          />
        )}
      </div>

      {editing && <ProductEditor initial={editing} onClose={() => setEditing(null)} />}
    </div>
  )
}

function Stat({
  label,
  value,
  sub,
  icon: Icon,
}: {
  label: string
  value: string
  sub?: string
  icon: React.ComponentType<{ className?: string }>
}) {
  return (
    <div className="rounded-3xl border border-border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        <Icon className="size-5 text-primary" />
      </div>
      <p className="mt-2 font-serif text-2xl">{value}</p>
      {sub && <p className="text-xs text-primary">{sub}</p>}
    </div>
  )
}

function Overview({ orders, loading }: { orders: Order[]; loading: boolean }) {
  const recent = orders.slice(0, 5)
  if (loading) return <p className="rounded-3xl border border-dashed border-border p-10 text-center text-muted-foreground">Loading orders…</p>
  if (orders.length === 0) {
    return <p className="rounded-3xl border border-dashed border-border p-10 text-center text-muted-foreground">No orders yet.</p>
  }
  return (
    <div className="rounded-3xl border border-border bg-card p-6 shadow-sm">
      <h2 className="font-serif text-lg">Recent orders</h2>
      <ul className="mt-4 divide-y divide-border">
        {recent.map((o) => (
          <li key={o.id} className="flex items-center justify-between py-3 text-sm">
            <div>
              <p className="font-medium">{o.fullName}</p>
              <p className="text-xs text-muted-foreground">
                {o.orderNumber} · {o.wilaya}
              </p>
            </div>
            <div className="text-right">
              <p className="font-medium text-primary">{formatDZD(o.total)}</p>
              <span className={cn("rounded-full px-2 py-0.5 text-xs capitalize", STATUS_STYLES[o.status])}>
                {o.status}
              </span>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}

function OrdersTable({
  orders,
  loading,
  onStatus,
}: {
  orders: Order[]
  loading: boolean
  onStatus: (id: number, s: OrderStatus) => void
}) {
  if (loading) {
    return <p className="rounded-3xl border border-dashed border-border p-10 text-center text-muted-foreground">Loading orders…</p>
  }
  if (orders.length === 0) {
    return (
      <p className="rounded-3xl border border-dashed border-border p-10 text-center text-muted-foreground">
        No orders yet. Orders placed in the store will appear here.
      </p>
    )
  }
  return (
    <div className="space-y-3">
      {orders.map((o) => (
        <div key={o.id} className="rounded-3xl border border-border bg-card p-5 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="font-medium">
                {o.fullName} · <span className="text-muted-foreground">{o.phone}</span>
              </p>
              <p className="text-xs text-muted-foreground">
                {o.orderNumber} · {new Date(o.createdAt).toLocaleDateString()} · {o.address}, {o.commune}, {o.wilaya}
              </p>
            </div>
            <p className="font-semibold text-primary">{formatDZD(o.total)}</p>
          </div>
          <ul className="mt-3 flex flex-wrap gap-2 text-xs text-muted-foreground">
            {o.items.map((i) => (
              <li key={`${i.productId}-${i.size ?? "na"}`} className="rounded-full bg-secondary px-2.5 py-1">
                {i.name} x{i.quantity}
              </li>
            ))}
          </ul>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <select
              value={o.status}
              onChange={(e) => onStatus(o.id, e.target.value as OrderStatus)}
              className="rounded-full border border-border bg-background px-3 py-1.5 text-xs"
            >
              <option value="new">New</option>
              <option value="confirmed">Confirmed</option>
              <option value="shipped">Shipped</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
            <span className={cn("rounded-full px-3 py-1 text-xs capitalize", STATUS_STYLES[o.status])}>{o.status}</span>
          </div>
        </div>
      ))}
    </div>
  )
}

function ProductsTable({
  products,
  loading,
  onEdit,
  onNew,
  onDelete,
}: {
  products: Product[]
  loading: boolean
  onEdit: (p: Product) => void
  onNew: () => void
  onDelete: (slug: string) => void
}) {
  return (
    <div>
      <button
        onClick={onNew}
        className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground"
      >
        <Plus className="size-4" /> Add product
      </button>
      {loading ? (
        <p className="rounded-3xl border border-dashed border-border p-10 text-center text-muted-foreground">Loading products…</p>
      ) : (
        <div className="space-y-3">
          {products.map((p) => (
            <div key={p.id} className="flex items-center gap-4 rounded-3xl border border-border bg-card p-4 shadow-sm">
              <div className="relative size-16 shrink-0 overflow-hidden rounded-2xl bg-secondary">
                <Image src={p.images[0] || "/placeholder.svg"} alt={p.name} fill sizes="64px" className="object-cover" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-medium">{p.name}</p>
                <p className="text-xs text-muted-foreground">
                  {CATEGORY_LABELS[p.category]} · {p.availability === "in-stock" ? "In stock" : "Out of stock"}
                </p>
              </div>
              <span className="text-sm font-medium text-primary">{formatDZD(p.price)}</span>
              <div className="flex gap-1">
                <button
                  onClick={() => onEdit(p)}
                  aria-label="Edit"
                  className="rounded-full p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"
                >
                  <Pencil className="size-4" />
                </button>
                <button
                  onClick={() => onDelete(p.slug)}
                  aria-label="Delete"
                  className="rounded-full p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

interface EditorForm {
  name: string
  description: string
  categorySlug: Category
  price: number
  oldPrice: number | ""
  material: string
  inStock: boolean
  isNew: boolean
  isBestSeller: boolean
  onPromotion: boolean
}

function ProductEditor({
  initial,
  onClose,
}: {
  initial: Product | "new"
  onClose: () => void
}) {
  const { addProduct, updateProduct } = useStore()
  const isNew = initial === "new"

  const [categories, setCategories] = useState<{ id: number; slug: Category; name: string }[]>([])
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(
    isNew ? null : (initial as Product).images[0] || null,
  )
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchCategories()
      .then((cats) => setCategories(cats.map((c) => ({ id: c.id, slug: c.slug as Category, name: c.name }))))
      .catch(() => setCategories([]))
  }, [])

  const base: EditorForm =
    initial === "new"
      ? {
          name: "",
          description: "",
          categorySlug: "rings",
          price: 0,
          oldPrice: "",
          material: "",
          inStock: true,
          isNew: true,
          isBestSeller: false,
          onPromotion: false,
        }
      : {
          name: initial.name,
          description: initial.description,
          categorySlug: initial.category,
          price: initial.price,
          oldPrice: initial.oldPrice ?? "",
          material: initial.material,
          inStock: initial.availability === "in-stock",
          isNew: initial.isNew,
          isBestSeller: initial.isBestSeller,
          onPromotion: initial.onPromotion,
        }

  const [form, setForm] = useState<EditorForm>(base)

  async function save() {
    setError(null)
    const category = categories.find((c) => c.slug === form.categorySlug)
    if (!category) {
      setError("Categories are still loading — please wait a moment and try again.")
      return
    }
    const payload: ProductWritePayload = {
      name: form.name,
      description: form.description,
      category: category.id,
      price: Number(form.price),
      old_price: form.oldPrice === "" ? null : Number(form.oldPrice),
      material: form.material,
      in_stock: form.inStock,
      is_new: form.isNew,
      is_best_seller: form.isBestSeller,
      on_promotion: form.onPromotion,
    }

    setSaving(true)
    try {
      if (isNew) {
        await addProduct(payload, imageFile)
      } else {
        await updateProduct((initial as Product).slug, payload, imageFile)
      }
      onClose()
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not save the product. Please try again.")
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-foreground/50 p-4 sm:items-center" role="dialog" aria-modal="true">
      <div className="max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-3xl bg-card p-6 shadow-xl">
        <h2 className="font-serif text-xl">{isNew ? "Add product" : "Edit product"}</h2>
        <div className="mt-4 space-y-3">
          <div className="block text-sm">
            <span className="mb-1 block font-medium">Product photo</span>
            <div className="flex items-center gap-4">
              <div className="relative size-20 shrink-0 overflow-hidden rounded-2xl border border-border bg-secondary">
                <Image
                  src={imagePreview || "/placeholder.svg"}
                  alt={form.name || "Product photo"}
                  fill
                  sizes="80px"
                  className="object-cover"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="inline-flex w-fit cursor-pointer items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-medium hover:bg-secondary">
                  <Plus className="size-3.5" /> Upload photo
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0]
                      if (!file) return
                      setImageFile(file)
                      const reader = new FileReader()
                      reader.onload = () => setImagePreview(reader.result as string)
                      reader.readAsDataURL(file)
                    }}
                  />
                </label>
                <p className="text-xs text-muted-foreground">JPG or PNG, square images look best.</p>
              </div>
            </div>
          </div>
          <label className="block text-sm">
            <span className="mb-1 block font-medium">Name</span>
            <input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </label>
          <div className="grid grid-cols-2 gap-3">
            <label className="block text-sm">
              <span className="mb-1 block font-medium">Price (DZD)</span>
              <input
                type="number"
                className="input"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
              />
            </label>
            <label className="block text-sm">
              <span className="mb-1 block font-medium">Old price (optional)</span>
              <input
                type="number"
                className="input"
                value={form.oldPrice}
                onChange={(e) => setForm({ ...form, oldPrice: e.target.value ? Number(e.target.value) : "" })}
              />
            </label>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <label className="block text-sm">
              <span className="mb-1 block font-medium">Category</span>
              <select
                className="input"
                value={form.categorySlug}
                onChange={(e) => setForm({ ...form, categorySlug: e.target.value as Category })}
              >
                {Object.entries(CATEGORY_LABELS).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-sm">
              <span className="mb-1 block font-medium">Availability</span>
              <select
                className="input"
                value={form.inStock ? "in-stock" : "out-of-stock"}
                onChange={(e) => setForm({ ...form, inStock: e.target.value === "in-stock" })}
              >
                <option value="in-stock">In stock</option>
                <option value="out-of-stock">Out of stock</option>
              </select>
            </label>
          </div>
          <label className="block text-sm">
            <span className="mb-1 block font-medium">Material</span>
            <input className="input" value={form.material} onChange={(e) => setForm({ ...form, material: e.target.value })} />
          </label>
          <label className="block text-sm">
            <span className="mb-1 block font-medium">Description</span>
            <textarea
              rows={3}
              className="input resize-none"
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </label>
          <div className="flex flex-wrap gap-4 text-sm">
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={form.isNew} onChange={(e) => setForm({ ...form, isNew: e.target.checked })} />
              New
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={form.isBestSeller}
                onChange={(e) => setForm({ ...form, isBestSeller: e.target.checked })}
              />
              Best seller
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={form.onPromotion}
                onChange={(e) => setForm({ ...form, onPromotion: e.target.checked })}
              />
              On promotion
            </label>
          </div>
        </div>
        {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
        <div className="mt-6 flex justify-end gap-3">
          <button onClick={onClose} className="rounded-full border border-border px-5 py-2.5 text-sm hover:bg-secondary">
            Cancel
          </button>
          <button
            onClick={save}
            disabled={!form.name.trim() || saving}
            className="rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground disabled:opacity-50"
          >
            {saving ? "Saving…" : "Save product"}
          </button>
        </div>
      </div>
    </div>
  )
}
