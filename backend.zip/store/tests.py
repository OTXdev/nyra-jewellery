import uuid
from datetime import timedelta

from rest_framework import status
from rest_framework.test import APITestCase
from rest_framework_simplejwt.tokens import AccessToken

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.cache import cache

from .models import (
    Category,
    ContactMessage,
    Order,
    Product,
    ProductImage,
    Wilaya,
)


from unittest.mock import patch

from django.db import IntegrityError
from django.test import TestCase




class OrderSaveRetryTests(TestCase):
    def build_order_data(self, **overrides):
        data = {
            "customer_name": "Alice Example",
            "phone": "+213555000000",
            "wilaya": "Algiers",
            "commune": "Hydra",
            "address": "12 Rue de la Paix",
            "subtotal": 1000,
            "delivery_fee": 300,
            "total": 1300,
        }
        data.update(overrides)
        return data

    def test_retry_after_real_order_number_unique_collision(self):
        existing = Order.objects.create(
            order_number="NYRA-AAAAAA",
            **self.build_order_data(),
        )

        original_filter = Order.objects.filter

        def fake_filter(*args, **kwargs):
            queryset = original_filter(*args, **kwargs)
            if kwargs.get("order_number") == "NYRA-AAAAAA":
                queryset.exists = lambda: False
            return queryset

        with patch("store.models.generate_order_number", side_effect=["NYRA-AAAAAA", "NYRA-BBBBBB"]), patch.object(
            Order.objects,
            "filter",
            side_effect=fake_filter,
        ):
            order = Order(**self.build_order_data())
            order.save()

        self.assertEqual(order.order_number, "NYRA-BBBBBB")
        self.assertEqual(Order.objects.filter(order_number="NYRA-BBBBBB").count(), 1)
        self.assertEqual(Order.objects.count(), 2)
        self.assertNotEqual(existing.pk, order.pk)

    def test_retry_is_bounded_to_three_attempts(self):
        for order_number in ["NYRA-AAAAAA", "NYRA-BBBBBB", "NYRA-CCCCCC"]:
            Order.objects.create(
                order_number=order_number,
                **self.build_order_data(),
            )

        original_filter = Order.objects.filter

        def fake_filter(*args, **kwargs):
            queryset = original_filter(*args, **kwargs)
            if kwargs.get("order_number") in {"NYRA-AAAAAA", "NYRA-BBBBBB", "NYRA-CCCCCC"}:
                queryset.exists = lambda: False
            return queryset

        with patch(
            "store.models.generate_order_number",
            side_effect=["NYRA-AAAAAA", "NYRA-BBBBBB", "NYRA-CCCCCC"],
        ) as generate_order_number, patch.object(Order.objects, "filter", side_effect=fake_filter):
            order = Order(**self.build_order_data())
            with self.assertRaises(IntegrityError):
                order.save()

        self.assertEqual(generate_order_number.call_count, 3)
        self.assertEqual(Order.objects.count(), 3)

    def test_explicit_order_number_is_not_regenerated(self):
        with patch("store.models.generate_order_number") as generate_order_number:
            order = Order(order_number="EXPLICIT-42", **self.build_order_data())
            order.save()

        self.assertEqual(order.order_number, "EXPLICIT-42")
        self.assertEqual(Order.objects.get(pk=order.pk).order_number, "EXPLICIT-42")
        generate_order_number.assert_not_called()

    def test_unrelated_integrity_error_is_not_swallowed(self):
        order = Order(
            customer_name="Alice Example",
            phone="+213555000000",
            wilaya="Algiers",
            commune="Hydra",
            address="12 Rue de la Paix",
            subtotal=None,
            delivery_fee=300,
            total=1300,
        )

        with self.assertRaises(IntegrityError):
            order.save()

def make_order(**overrides):
    defaults = {
        "customer_name": "Test Customer",
        "phone": "0550123456",
        "wilaya": "16 - Alger",
        "commune": "Alger Centre",
        "address": "Example Street 1",
        "subtotal": 1000,
        "delivery_fee": 0,
        "total": 1000,
    }
    defaults.update(overrides)
    return Order.objects.create(**defaults)


class BulkDeleteIDValidationTests(APITestCase):
    """Regression tests for POST /api/admin/orders/bulk-delete/ ID validation."""

    def setUp(self):
        User = get_user_model()
        self.staff_user = User.objects.create_user(
            username="admin", password="testpass", is_staff=True
        )
        self.client.force_authenticate(self.staff_user)

        self.order_1 = make_order(customer_name="Order One")
        self.order_2 = make_order(customer_name="Order Two")

        self.url = "/api/admin/orders/bulk-delete/"

    def _post(self, payload):
        return self.client.post(self.url, payload, format="json")

    def test_valid_integer_ids_delete_orders(self):
        """Valid integer IDs preserve the existing bulk-delete behavior."""
        response = self._post({"ids": [self.order_1.id, self.order_2.id]})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(Order.objects.filter(pk__in=[self.order_1.id, self.order_2.id]).count(), 0)

    def test_valid_single_integer_id_deletes_order(self):
        response = self._post({"ids": [self.order_1.id]})

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertFalse(Order.objects.filter(pk=self.order_1.id).exists())
        self.assertTrue(Order.objects.filter(pk=self.order_2.id).exists())

    def test_missing_ids_key_returns_400(self):
        response = self._post({})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 2)

    def test_ids_not_a_list_returns_400(self):
        response = self._post({"ids": "1,2,3"})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 2)

    def test_empty_list_returns_400(self):
        response = self._post({"ids": []})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 2)

    def test_string_element_returns_400(self):
        response = self._post({"ids": [self.order_1.id, "abc"]})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 2)

    def test_float_element_returns_400(self):
        response = self._post({"ids": [self.order_1.id, 1.5]})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 2)

    def test_null_element_returns_400(self):
        response = self._post({"ids": [self.order_1.id, None]})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 2)

    def test_object_element_returns_400(self):
        response = self._post({"ids": [self.order_1.id, {"id": 1}]})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 2)

    def test_list_element_returns_400(self):
        response = self._post({"ids": [self.order_1.id, [1, 2]]})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 2)

    def test_boolean_element_returns_400(self):
        """Booleans must not be treated as integers (bool is an int subclass)."""
        response = self._post({"ids": [self.order_1.id, True]})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 2)

    def test_mixed_valid_and_invalid_ids_returns_400_and_deletes_nothing(self):
        """Malformed IDs must never reach the ORM."""
        response = self._post({"ids": [self.order_1.id, "bad"]})

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 2)

class ThrottlingTestMixin:
    """Helpers to build valid test data for public POST endpoints."""

    def _make_test_data(self):
        User = get_user_model()
        self.staff_user = User.objects.create_user(
            username="admin", password="testpass", is_staff=True
        )
        self.category = Category.objects.create(name="Rings")
        self.product = Product.objects.create(
            name="Test Ring", category=self.category, price=1000, in_stock=True
        )
        self.wilaya = Wilaya.objects.create(
            code="16", name="Alger", delivery_fee=800, stopdesk_fee=500
        )

    def setUp(self):
   
        cache.clear()

    def _order_payload(self):
        return {
            "customer_name": "Test Customer",
            "phone": "0550123456",
            "wilaya_id": self.wilaya.id,
            "commune": "Alger Centre",
            "address": "Example Street 1",
            "delivery_method": "stopdesk",
            "items": [
                {"product_id": self.product.id, "quantity": 1, "size": "7"}
            ],
            "idempotency_key": str(uuid.uuid4()),
        }

    def _contact_payload(self):
        return {
            "name": "Test User",
            "email": "test@example.com",
            "phone": "0550123456",
            "subject": "Hello",
            "message": "This is a test contact message.",
        }


class StaffLoginThrottleTests(ThrottlingTestMixin, APITestCase):
    """POST /api/auth/login/ must be limited to 5/min per client."""

    def setUp(self):
        super().setUp()
        self._make_test_data()
        self.url = "/api/auth/login/"
        self.payload = {"username": "admin", "password": "testpass"}

    def test_requests_below_limit_succeed(self):
        for _ in range(5):
            response = self.client.post(self.url, self.payload, format="json")
            self.assertNotEqual(response.status_code, status.HTTP_429_TOO_MANY_REQUESTS)

    def test_exceeding_limit_returns_429(self):
        for _ in range(5):
            self.client.post(self.url, self.payload, format="json")
        response = self.client.post(self.url, self.payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_429_TOO_MANY_REQUESTS)


class OrderCreateThrottleTests(ThrottlingTestMixin, APITestCase):
    """POST /api/orders/ must be limited to 10/min per client."""

    def setUp(self):
        super().setUp()
        self._make_test_data()
        self.url = "/api/orders/"
        self.payload = self._order_payload()

    def test_requests_below_limit_succeed(self):
        for _ in range(10):
          
            self.payload["idempotency_key"] = str(uuid.uuid4())
            response = self.client.post(self.url, self.payload, format="json")
            self.assertNotEqual(response.status_code, status.HTTP_429_TOO_MANY_REQUESTS)

    def test_exceeding_limit_returns_429(self):
        for _ in range(10):
            self.payload["idempotency_key"] = str(uuid.uuid4())
            self.client.post(self.url, self.payload, format="json")
        self.payload["idempotency_key"] = str(uuid.uuid4())
        response = self.client.post(self.url, self.payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_429_TOO_MANY_REQUESTS)


class ContactMessageThrottleTests(ThrottlingTestMixin, APITestCase):
    """POST /api/contact/ must be limited to 10/min per client."""

    def setUp(self):
        super().setUp()
        self._make_test_data()
        self.url = "/api/contact/"
        self.payload = self._contact_payload()

    def test_requests_below_limit_succeed(self):
        for _ in range(10):
            response = self.client.post(self.url, self.payload, format="json")
            self.assertNotEqual(response.status_code, status.HTTP_429_TOO_MANY_REQUESTS)

    def test_exceeding_limit_returns_429(self):
        for _ in range(10):
            self.client.post(self.url, self.payload, format="json")
        response = self.client.post(self.url, self.payload, format="json")
        self.assertEqual(response.status_code, status.HTTP_429_TOO_MANY_REQUESTS)


class UnrelatedEndpointsNotThrottledTests(ThrottlingTestMixin, APITestCase):
    """Unrelated anonymous GET endpoints must not be throttled."""

    def test_public_get_endpoints_are_not_throttled(self):
        # Many requests to unrelated endpoints should never return 429.
        for _ in range(60):
            response = self.client.get("/api/wilayas/")
            self.assertNotEqual(response.status_code, status.HTTP_429_TOO_MANY_REQUESTS)




class OrderItemSizeValidationTests(APITestCase):
    """
    Regression tests for ring/product size validation in OrderCreateSerializer.

    A product that defines sizes requires the customer to submit one of the
    allowed sizes. Non-sized products (sizes is None/empty) never require a
    size.
    """

    def setUp(self):
        # Isolate throttle counters between tests.
        cache.clear()

        User = get_user_model()
        self.staff_user = User.objects.create_user(
            username="admin", password="testpass", is_staff=True
        )
        self.category = Category.objects.create(name="Rings")
        self.wilaya = Wilaya.objects.create(
            code="16", name="Alger", delivery_fee=800, stopdesk_fee=500
        )

        self.sized_product = Product.objects.create(
            name="Sized Ring",
            category=self.category,
            price=1000,
            in_stock=True,
            sizes=["6", "7", "8"],
        )
        self.non_sized_product = Product.objects.create(
            name="Adjustable Ring",
            category=self.category,
            price=1000,
            in_stock=True,
            sizes=None,
        )

        self.url = "/api/orders/"

    def _payload(self, product_id, size="", include_size=True):
        item = {"product_id": product_id, "quantity": 1}
        if include_size:
            item["size"] = size
        return {
            "customer_name": "Test Customer",
            "phone": "0550123456",
            "wilaya_id": self.wilaya.id,
            "commune": "Alger Centre",
            "delivery_method": "stopdesk",
            "items": [item],
            "idempotency_key": str(uuid.uuid4()),
        }

    def test_sized_product_with_valid_size_is_accepted(self):
        response = self.client.post(
            self.url, self._payload(self.sized_product.id, size="7"), format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["items"][0]["size"], "7")

    def test_sized_product_with_invalid_size_is_rejected(self):
        response = self.client.post(
            self.url, self._payload(self.sized_product.id, size="99"), format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("items", response.data["errors"])
        self.assertIn("size", response.data["errors"]["items"][0])

    def test_sized_product_with_missing_size_is_rejected(self):
        response = self.client.post(
            self.url, self._payload(self.sized_product.id, include_size=False), format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("items", response.data["errors"])
        self.assertIn("size", response.data["errors"]["items"][0])

    def test_sized_product_with_blank_size_is_rejected(self):
        response = self.client.post(
            self.url, self._payload(self.sized_product.id, size=""), format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("items", response.data["errors"])
        self.assertIn("size", response.data["errors"]["items"][0])

    def test_sized_product_with_whitespace_only_size_is_rejected(self):
        response = self.client.post(
            self.url, self._payload(self.sized_product.id, size="   "), format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn("items", response.data["errors"])
        self.assertIn("size", response.data["errors"]["items"][0])

    def test_non_sized_product_without_size_is_accepted(self):
        response = self.client.post(
            self.url,
            self._payload(self.non_sized_product.id, include_size=False),
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data["items"][0]["size"], "")

    def test_non_sized_product_with_arbitrary_size_is_accepted(self):
        response = self.client.post(
            self.url, self._payload(self.non_sized_product.id, size="Medium"), format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)



class FreeGiftEligibilityTests(APITestCase):
    """
    The surprise gift is a store-owner surprise. Eligibility is computed
    server-side from the trusted stored subtotal — the customer can never
    submit or select a gift, and no gift field is stored on the Order model.
    """

    def setUp(self):
        cache.clear()

        User = get_user_model()
        self.staff_user = User.objects.create_user(
            username="admin", password="testpass", is_staff=True
        )
        self.client.force_authenticate(self.staff_user)
        self.category = Category.objects.create(name="Rings")
        self.wilaya = Wilaya.objects.create(
            code="16", name="Alger", delivery_fee=800, stopdesk_fee=500
        )
       
        self.product = Product.objects.create(
            name="Test Ring",
            category=self.category,
            price=1000,
            in_stock=True,
            sizes=["7"],
        )
        self.url = "/api/orders/"

    def _payload(self, quantity, extra=None):
        payload = {
            "customer_name": "Test Customer",
            "phone": "0550123456",
            "wilaya_id": self.wilaya.id,
            "commune": "Alger Centre",
            "delivery_method": "stopdesk",
            "items": [{"product_id": self.product.id, "quantity": quantity, "size": "7"}],
            "idempotency_key": str(uuid.uuid4()),
        }
        if extra:
            payload.update(extra)
        return payload

    def _create_order(self, subtotal):
      
        return make_order(
            customer_name="Test Customer",
            subtotal=subtotal,
            delivery_fee=0,
            total=subtotal,
        )

    # 1. Below the threshold -> not eligible
    def test_below_threshold_is_not_eligible(self):
        order = self._create_order(subtotal=9000)
        response = self.client.get(f"/api/admin/orders/{order.id}/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertFalse(response.data["is_gift_eligible"])

    # 2. Exactly at the threshold -> eligible (>= 10000 follows the existing rule)
    def test_exactly_at_threshold_is_eligible(self):
        order = self._create_order(subtotal=10000)
        response = self.client.get(f"/api/admin/orders/{order.id}/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data["is_gift_eligible"])

    # 3. Above the threshold -> eligible
    def test_above_threshold_is_eligible(self):
        order = self._create_order(subtotal=12000)
        response = self.client.get(f"/api/admin/orders/{order.id}/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data["is_gift_eligible"])

    def test_client_cannot_manipulate_eligibility_with_free_gift_field(self):
    
        response = self.client.post(
            self.url,
            self._payload(
                quantity=9,
                extra={"free_gift": True, "free_gift_selected": "diamond-ring"},
            ),
            format="json",
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        # Eligibility is computed from the stored subtotal only (9000 < 10000).
        self.assertFalse(response.data["is_gift_eligible"])
        # The stored order has no gift field and the subtotal is trusted.
        order = Order.objects.get(order_number=response.data["order_number"])
        self.assertEqual(order.subtotal, 9000)

    # 5. Admin order list shows eligibility only for qualifying orders.
    def test_admin_list_shows_eligibility_for_qualifying_orders(self):
        eligible = self._create_order(subtotal=12000)
        not_eligible = self._create_order(subtotal=5000)
        response = self.client.get("/api/admin/orders/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        orders = response.data["results"] if isinstance(response.data, dict) else response.data
        by_id = {o["id"]: o for o in orders}
        self.assertTrue(by_id[eligible.id]["is_gift_eligible"])
        self.assertFalse(by_id[not_eligible.id]["is_gift_eligible"])

 
    def test_customer_creation_response_has_eligibility(self):
        response = self.client.post(
            self.url, self._payload(quantity=12), format="json"
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(response.data["is_gift_eligible"])

class StaffOnlyEndpointAccessTests(APITestCase):
    """
    Regression tests for the admin/staff authorization boundary:
    unauthenticated and non-staff users must never reach admin data,
    and staff users must be able to.
    """

    def setUp(self):
        cache.clear()
        User = get_user_model()
        self.staff_user = User.objects.create_user(
            username="admin", password="testpass", is_staff=True
        )
        self.regular_user = User.objects.create_user(
            username="shopper", password="testpass", is_staff=False
        )
        self.category = Category.objects.create(name="Rings")
        self.wilaya = Wilaya.objects.create(
            code="16", name="Alger", delivery_fee=800, stopdesk_fee=500
        )
        self.order = make_order(customer_name="Some Customer")

    def _assert_denied_for_anonymous_and_non_staff(self, method, url, data=None):
        # Anonymous: no auth at all.
        response = getattr(self.client, method)(url, data or {}, format="json")
        self.assertIn(
            response.status_code,
            (status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN),
            f"anonymous {method.upper()} {url} returned {response.status_code}",
        )

        # Authenticated but not staff.
        self.client.force_authenticate(self.regular_user)
        response = getattr(self.client, method)(url, data or {}, format="json")
        self.assertIn(
            response.status_code,
            (status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN),
            f"non-staff {method.upper()} {url} returned {response.status_code}",
        )
        self.client.force_authenticate(None)

    def test_admin_orders_list_denied_to_anonymous_and_non_staff(self):
        self._assert_denied_for_anonymous_and_non_staff("get", "/api/admin/orders/")

    def test_admin_stats_denied_to_anonymous_and_non_staff(self):
        self._assert_denied_for_anonymous_and_non_staff("get", "/api/admin/stats/")

    def test_admin_contact_messages_denied_to_anonymous_and_non_staff(self):
        self._assert_denied_for_anonymous_and_non_staff("get", "/api/admin/contact-messages/")

    def test_admin_account_update_denied_to_anonymous_and_non_staff(self):
        self._assert_denied_for_anonymous_and_non_staff(
            "patch", "/api/admin/account/", {"username": "hacker"}
        )

    def test_admin_bulk_delete_denied_to_anonymous_and_non_staff(self):
        self._assert_denied_for_anonymous_and_non_staff(
            "post", "/api/admin/orders/bulk-delete/", {"ids": [self.order.id]}
        )
        # Confirm nothing was actually deleted by the denied attempts.
        self.assertTrue(Order.objects.filter(pk=self.order.id).exists())

    def test_product_write_denied_to_anonymous_and_non_staff(self):
        payload = {
            "name": "Sneaky Ring",
            "category": self.category.id,
            "price": 100,
        }
        self._assert_denied_for_anonymous_and_non_staff("post", "/api/products/", payload)
        self.assertFalse(Product.objects.filter(name="Sneaky Ring").exists())

    def test_product_read_allowed_to_anonymous(self):
        Product.objects.create(name="Public Ring", category=self.category, price=1000)
        response = self.client.get("/api/products/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_staff_user_can_access_admin_endpoints(self):
        self.client.force_authenticate(self.staff_user)

        response = self.client.get("/api/admin/orders/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        response = self.client.get("/api/admin/stats/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        response = self.client.get("/api/admin/contact-messages/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)


class OrderIdempotencyHTTPTests(APITestCase):
    """
    HTTP-level regression tests for duplicate order protection: the same
    idempotency key submitted twice must never create two orders.
    """

    def setUp(self):
        cache.clear()
        self.category = Category.objects.create(name="Rings")
        self.wilaya = Wilaya.objects.create(
            code="16", name="Alger", delivery_fee=800, stopdesk_fee=500
        )
        self.product = Product.objects.create(
            name="Idempotency Ring", category=self.category, price=1000, in_stock=True
        )
        self.url = "/api/orders/"

    def _payload(self, key, quantity=1):
        return {
            "customer_name": "Test Customer",
            "phone": "0550123456",
            "wilaya_id": self.wilaya.id,
            "commune": "Alger Centre",
            "delivery_method": "stopdesk",
            "items": [{"product_id": self.product.id, "quantity": quantity}],
            "idempotency_key": key,
        }

    def test_same_key_and_payload_returns_same_order_not_a_duplicate(self):
        key = str(uuid.uuid4())
        first = self.client.post(self.url, self._payload(key), format="json")
        second = self.client.post(self.url, self._payload(key), format="json")

        self.assertEqual(first.status_code, status.HTTP_201_CREATED)
        self.assertEqual(second.status_code, status.HTTP_201_CREATED)
        self.assertEqual(first.data["order_number"], second.data["order_number"])
        self.assertEqual(Order.objects.count(), 1)

    def test_same_key_with_different_payload_is_rejected(self):
        key = str(uuid.uuid4())
        first = self.client.post(self.url, self._payload(key, quantity=1), format="json")
        second = self.client.post(self.url, self._payload(key, quantity=2), format="json")

        self.assertEqual(first.status_code, status.HTTP_201_CREATED)
        self.assertEqual(second.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertEqual(Order.objects.count(), 1)

    def test_different_keys_create_separate_orders(self):
        first = self.client.post(self.url, self._payload(str(uuid.uuid4())), format="json")
        second = self.client.post(self.url, self._payload(str(uuid.uuid4())), format="json")

        self.assertEqual(first.status_code, status.HTTP_201_CREATED)
        self.assertEqual(second.status_code, status.HTTP_201_CREATED)
        self.assertNotEqual(first.data["order_number"], second.data["order_number"])
        self.assertEqual(Order.objects.count(), 2)


class InvalidExpiredTokenTests(APITestCase):
    """
    Regression tests for the cookie-JWT authentication path with malformed,
    invalid, and expired tokens — these must fail closed with 401, never a
    500 or an authenticated session.
    """

    def setUp(self):
        cache.clear()
        User = get_user_model()
        self.staff_user = User.objects.create_user(
            username="admin", password="testpass", is_staff=True
        )

    def test_garbage_access_cookie_returns_401_not_500(self):
        self.client.cookies[settings.JWT_AUTH_COOKIE] = "not-a-real-jwt"
        response = self.client.get("/api/admin/stats/")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_expired_access_cookie_returns_401(self):
        token = AccessToken.for_user(self.staff_user)
        token.set_exp(lifetime=timedelta(seconds=-1))
        self.client.cookies[settings.JWT_AUTH_COOKIE] = str(token)
        response = self.client.get("/api/admin/stats/")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_garbage_refresh_cookie_returns_401_and_clears_cookies(self):
        self.client.cookies[settings.JWT_REFRESH_COOKIE] = "not-a-real-jwt"
        response = self.client.post("/api/auth/refresh/")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_missing_refresh_cookie_returns_401(self):
        response = self.client.post("/api/auth/refresh/")
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_valid_access_cookie_authenticates_staff_request(self):
        token = AccessToken.for_user(self.staff_user)
        self.client.cookies[settings.JWT_AUTH_COOKIE] = str(token)
        response = self.client.get("/api/admin/stats/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_non_staff_valid_token_denied_admin_access(self):
        User = get_user_model()
        regular = User.objects.create_user(username="shopper2", password="testpass", is_staff=False)
        token = AccessToken.for_user(regular)
        self.client.cookies[settings.JWT_AUTH_COOKIE] = str(token)
        response = self.client.get("/api/admin/stats/")
        self.assertIn(response.status_code, (status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN))
